<?php

// Array of 3 students with name and marks
$students = [
    ['name' => 'Alice', 'marks' => 75],
    ['name' => 'Bob', 'marks' => 42],
    ['name' => 'Charlie', 'marks' => 50]
];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Marksheet</title>
</head>
<body>

    <h2>Student Results</h2>

    <?php
    foreach ($students as $student) {
        $name = $student['name'];
        $marks = $student['marks'];

        // Check pass or fail
        if ($marks >= 50) {
            $status = "Passed";
        } else {
            $status = "Failed";
        }

        // Print the details directly
        echo "Name: $name | Marks: $marks | Status: $status<br>";
    }
    ?>

</body>
</html>